
#pragma once
#include <string>
#include <map>
#include <iostream>
using namespace std;

class Leaderboard {
    map<string, int> scores;
public:
    void addBadge(string player);
    void display() const;
};
