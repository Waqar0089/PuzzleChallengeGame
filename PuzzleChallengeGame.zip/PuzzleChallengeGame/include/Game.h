
#pragma once
#include <string>
using namespace std;

class Game {
protected:
    string title;
public:
    Game(string t) : title(t) {}
    virtual void play() = 0;
    string getTitle() const { return title; }
    virtual ~Game() {}
};
