
#pragma once
#include <string>
using namespace std;

class Player {
    string username;
    string password;
    string badges[10];
    int badgeCount = 0;
public:
    Player(string uname, string pass) : username(uname), password(pass) {}
    string getUsername() const { return username; }
    bool authenticate(string pass) const { return password == pass; }
    void addBadge(string badge);
    void viewBadges() const;
    static void savePlayerData(const Player& player);
    static Player* loadPlayer(string uname, string pass);
};
