
#pragma once
#include "Game.h"
#include <iostream>
#include <cstdlib>

class MathChallenge : public Game {
public:
    MathChallenge() : Game("Math Challenge") {}
    void play() override;
};
