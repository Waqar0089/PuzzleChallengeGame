
#pragma once
#include "Game.h"
#include <string>
#include <iostream>
#include <cstdlib>
#include <algorithm>

class Anagrams : public Game {
    string words[4] = {"apple", "banana", "cherry", "grape"};
public:
    Anagrams() : Game("Anagrams") {}
    void play() override;
};
