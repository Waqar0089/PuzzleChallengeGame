
#pragma once
#include "Game.h"
#include <iostream>
#include <cstdlib>

class MissingNumbers : public Game {
public:
    MissingNumbers() : Game("Missing Numbers") {}
    void play() override;
};
