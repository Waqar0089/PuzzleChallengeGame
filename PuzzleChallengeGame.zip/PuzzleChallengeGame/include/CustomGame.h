
#pragma once
#include "Game.h"
#include <iostream>
#include <cstdlib>

class CustomGame : public Game {
public:
    CustomGame() : Game("Custom Game") {}
    void play() override;
};
