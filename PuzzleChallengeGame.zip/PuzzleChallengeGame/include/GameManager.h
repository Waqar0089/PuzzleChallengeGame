
#pragma once
#include "Player.h"
#include "Leaderboard.h"
#include "Game.h"
#include <iostream>
using namespace std;

class GameManager {
    Player* currentPlayer = nullptr;
    Leaderboard leaderboard;
    Game* games[4];
public:
    GameManager(Game* g1, Game* g2, Game* g3, Game* g4);
    void run();
};
