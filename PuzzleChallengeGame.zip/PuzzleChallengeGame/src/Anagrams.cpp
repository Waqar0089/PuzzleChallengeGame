
#include "Anagrams.h"
using namespace std;

void Anagrams::play() {
    string word = words[rand() % 4];
    string shuffled = word;
    random_shuffle(shuffled.begin(), shuffled.end());
    cout << "Unscramble this word: " << shuffled << endl;
    string answer;
    cin >> answer;
    if (answer == word) {
        cout << "Correct!" << endl;
    } else {
        cout << "Wrong! The word was " << word << "." << endl;
    }
}
