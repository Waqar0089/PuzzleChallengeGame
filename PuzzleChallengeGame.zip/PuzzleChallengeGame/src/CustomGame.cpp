
#include "CustomGame.h"
using namespace std;

void CustomGame::play() {
    cout << "Custom Game: Guess a number between 1 and 5." << endl;
    int target = rand() % 5 + 1;
    int guess;
    cin >> guess;
    if (guess == target) {
        cout << "Correct!" << endl;
    } else {
        cout << "Wrong! The number was " << target << "." << endl;
    }
}
