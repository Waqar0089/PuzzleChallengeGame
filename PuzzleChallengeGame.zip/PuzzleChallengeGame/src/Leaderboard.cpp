
#include "Leaderboard.h"
using namespace std;

void Leaderboard::addBadge(string player) {
    scores[player]++;
}

void Leaderboard::display() const {
    cout << "Leaderboard:" << endl;
    for (const auto& score : scores) {
        cout << score.first << ": " << score.second << " badges" << endl;
    }
}
