
#include "Player.h"
#include <iostream>
#include <fstream>
using namespace std;

void Player::addBadge(string badge) {
    if (badgeCount < 10) {
        badges[badgeCount++] = badge;
    }
}

void Player::viewBadges() const {
    cout << "Badges:" << endl;
    for (int i = 0; i < badgeCount; i++) {
        cout << badges[i] << endl;
    }
}

void Player::savePlayerData(const Player& player) {
    ofstream file("players.txt", ios::app);
    file << player.username << " " << player.password << endl;
    file.close();
}

Player* Player::loadPlayer(string uname, string pass) {
    ifstream file("players.txt");
    string u, p;
    while (file >> u >> p) {
        if (u == uname && p == pass) {
            return new Player(u, p);
        }
    }
    return nullptr;
}
