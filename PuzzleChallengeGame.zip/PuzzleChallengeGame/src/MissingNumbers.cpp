
#include "MissingNumbers.h"
using namespace std;

void MissingNumbers::play() {
    int base = rand() % 10 + 1;
    cout << "Fill in the missing number: " << base << ", " << base + 1 << ", ?, " << base + 3 << endl;
    int answer;
    cin >> answer;
    if (answer == base + 2) {
        cout << "Correct!" << endl;
    } else {
        cout << "Wrong! The answer is " << base + 2 << "." << endl;
    }
}
