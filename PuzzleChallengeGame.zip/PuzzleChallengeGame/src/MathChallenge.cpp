
#include "MathChallenge.h"
using namespace std;

void MathChallenge::play() {
    int a = rand() % 10 + 1;
    int b = rand() % 10 + 1;
    cout << "What is " << a << " + " << b << "?" << endl;
    int answer;
    cin >> answer;
    if (answer == a + b) {
        cout << "Correct!" << endl;
    } else {
        cout << "Wrong! The answer is " << a + b << "." << endl;
    }
}
