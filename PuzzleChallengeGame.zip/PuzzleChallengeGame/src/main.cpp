
#include "MathChallenge.h"
#include "Anagrams.h"
#include "MissingNumbers.h"
#include "CustomGame.h"
#include "GameManager.h"

int main() {
    MathChallenge math;
    Anagrams anagrams;
    MissingNumbers missing;
    CustomGame custom;
    GameManager manager(&math, &anagrams, &missing, &custom);
    manager.run();
    return 0;
}
