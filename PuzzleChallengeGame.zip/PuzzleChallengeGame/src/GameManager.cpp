
#include "GameManager.h"
using namespace std;

GameManager::GameManager(Game* g1, Game* g2, Game* g3, Game* g4) {
    games[0] = g1;
    games[1] = g2;
    games[2] = g3;
    games[3] = g4;
}

void GameManager::run() {
    while (true) {
        cout << "1. Sign Up\n2. Sign In\n3. Play\n4. View Badges\n5. View Leaderboard\n6. Exit" << endl;
        int choice;
        cin >> choice;
        switch (choice) {
            case 1:
                // Sign Up implementation
                break;
            case 2:
                // Sign In implementation
                break;
            case 3:
                // Play Game
                break;
            case 4:
                // View Badges
                break;
            case 5:
                // View Leaderboard
                break;
            case 6:
                return;
            default:
                cout << "Invalid option!" << endl;
        }
    }
}
